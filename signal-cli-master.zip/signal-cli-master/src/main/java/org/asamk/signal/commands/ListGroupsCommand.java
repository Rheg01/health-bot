package org.asamk.signal.commands;

import com.fasterxml.jackson.annotation.JsonInclude;

import net.sourceforge.argparse4j.impl.Arguments;
import net.sourceforge.argparse4j.inf.Namespace;
import net.sourceforge.argparse4j.inf.Subparser;

import org.asamk.signal.commands.exceptions.CommandException;
import org.asamk.signal.manager.Manager;
import org.asamk.signal.manager.api.Group;
import org.asamk.signal.manager.api.GroupMember;
import org.asamk.signal.manager.api.RecipientAddress;
import org.asamk.signal.output.JsonWriter;
import org.asamk.signal.output.OutputWriter;
import org.asamk.signal.output.PlainTextWriter;
import org.asamk.signal.util.CommandUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

public class ListGroupsCommand implements JsonRpcLocalCommand {

    private static final Logger logger = LoggerFactory.getLogger(ListGroupsCommand.class);

    @Override
    public String getName() {
        return "listGroups";
    }

    @Override
    public void attachToSubparser(final Subparser subparser) {
        subparser.help("List group information including names, ids, active status, blocked status and members");
        subparser.addArgument("-d", "--detailed")
                .action(Arguments.storeTrue())
                .help("List the members and group invite links of each group. If output=json, then this is always set");
        subparser.addArgument("-g", "--group-id").help("Specify one or more group IDs to show.").nargs("*");
    }

    private static Set<String> resolveMembers(Set<GroupMember> addresses) {
        return addresses.stream()
                .map(m -> m.recipientAddress().getLegacyIdentifier() + (m.isAdmin() ? "{ADMIN}" : "") + (
                        m.labelEmoji() != null || m.label() != null ? "(" + (
                                m.labelEmoji() != null ? m.labelEmoji() : ""
                        ) + (
                                m.label() != null ? m.label() : ""
                        ) + ")" : ""
                ))
                .collect(Collectors.toSet());
    }

    private static Set<String> resolveMemberAddress(Set<RecipientAddress> addresses) {
        return addresses.stream().map(RecipientAddress::getLegacyIdentifier).collect(Collectors.toSet());
    }

    private static Set<JsonGroupMemberAddress> resolveJsonMembers(Set<RecipientAddress> addresses) {
        return addresses.stream()
                .map(address -> new JsonGroupMemberAddress(address.number().orElse(null),
                        address.uuid().map(UUID::toString).orElse(null)))
                .collect(Collectors.toSet());
    }

    private static Set<JsonGroupMember> resolveFullJsonMembers(Set<GroupMember> addresses) {
        return addresses.stream().map(member -> {
            final var address = member.recipientAddress();
            return new JsonGroupMember(address.number().orElse(null),
                    address.uuid().map(UUID::toString).orElse(null),
                    member.isAdmin(),
                    member.labelEmoji(),
                    member.label());
        }).collect(Collectors.toSet());
    }

    private static void printGroupPlainText(PlainTextWriter writer, Group group, boolean detailed) {
        if (detailed) {
            final var groupInviteLink = group.groupInviteLinkUrl();

            writer.println(
                    "Id: {} Name: {} Description: {} Active: {} Blocked: {} Members: {} Pending members: {} Requesting members: {} Banned: {} Message expiration: {} Link: {}",
                    group.groupId().toBase64(),
                    group.title(),
                    group.description(),
                    group.isMember(),
                    group.isBlocked(),
                    resolveMembers(group.members()),
                    resolveMemberAddress(group.pendingMembers()),
                    resolveMemberAddress(group.requestingMembers()),
                    resolveMemberAddress(group.bannedMembers()),
                    group.messageExpirationTimer() == 0 ? "disabled" : group.messageExpirationTimer() + "s",
                    groupInviteLink == null ? '-' : groupInviteLink.getUrl());
        } else {
            writer.println("Id: {} Name: {}  Active: {} Blocked: {}",
                    group.groupId().toBase64(),
                    group.title(),
                    group.isMember(),
                    group.isBlocked());
        }
    }

    @Override
    public void handleCommand(
            final Namespace ns,
            final Manager m,
            final OutputWriter outputWriter
    ) throws CommandException {
        final var groupIdStrings = ns.<String>getList("group-id");
        final var groupIds = CommandUtil.getGroupIds(groupIdStrings);
        var groups = groupIds.isEmpty() ? m.getGroups() : m.getGroups(groupIds);

        switch (outputWriter) {
            case JsonWriter jsonWriter -> {
                var jsonGroups = groups.stream().map(group -> {
                    final var groupInviteLink = group.groupInviteLinkUrl();

                    return new JsonGroup(group.groupId().toBase64(),
                            group.title(),
                            group.description(),
                            group.isMember(),
                            group.isBlocked(),
                            group.messageExpirationTimer(),
                            resolveFullJsonMembers(group.members()),
                            resolveJsonMembers(group.pendingMembers()),
                            resolveJsonMembers(group.requestingMembers()),
                            resolveJsonMembers(group.members()
                                    .stream()
                                    .filter(GroupMember::isAdmin)
                                    .map(GroupMember::recipientAddress)
                                    .collect(Collectors.toSet())),
                            resolveJsonMembers(group.bannedMembers()),
                            group.permissionAddMember().name(),
                            group.permissionEditDetails().name(),
                            group.permissionSendMessage().name(),
                            groupInviteLink == null ? null : groupInviteLink.getUrl());
                }).toList();
                jsonWriter.write(jsonGroups);
            }
            case PlainTextWriter writer -> {
                boolean detailed = Boolean.TRUE.equals(ns.getBoolean("detailed"));
                for (var group : groups) {
                    printGroupPlainText(writer, group, detailed);
                }
            }
        }
    }

    private record JsonGroup(
            String id,
            String name,
            String description,
            boolean isMember,
            boolean isBlocked,
            int messageExpirationTime,
            Set<JsonGroupMember> members,
            Set<JsonGroupMemberAddress> pendingMembers,
            Set<JsonGroupMemberAddress> requestingMembers,
            @Deprecated Set<JsonGroupMemberAddress> admins,
            Set<JsonGroupMemberAddress> banned,
            String permissionAddMember,
            String permissionEditDetails,
            String permissionSendMessage,
            String groupInviteLink
    ) {}

    private record JsonGroupMemberAddress(String number, String uuid) {}

    private record JsonGroupMember(
            String number,
            String uuid,
            boolean isAdmin,
            @JsonInclude(JsonInclude.Include.NON_NULL) String labelEmoji,
            @JsonInclude(JsonInclude.Include.NON_NULL) String label
    ) {}
}
